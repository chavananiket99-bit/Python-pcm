import os
import io
import tempfile
import subprocess
import sys
import gc
import traceback
import logging
from flask import Flask, request, send_file, render_template

# Setup logging to capture all errors
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    stream=sys.stderr
)
logger = logging.getLogger(__name__)

app = Flask(__name__)
# NOTE: Do NOT register custom SIGTERM/SIGINT handlers here.
# Gunicorn already manages worker lifecycle and signal handling correctly.
# A custom handler calling sys.exit(0) would kill an in-flight upload request.

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/process', methods=['POST'])
def process_files():
    try:
        uploaded_files = request.files.getlist("pdf_files")
        if not uploaded_files or not uploaded_files[0].filename:
            return "No files uploaded", 400

        # Process files within an isolated temporary directory
        with tempfile.TemporaryDirectory() as temp_dir:
            pdf_dir = os.path.join(temp_dir, 'pdfs')
            json_dir = os.path.join(temp_dir, 'jsons')
            img_dir = os.path.join(temp_dir, 'images')
            out_excel = os.path.join(temp_dir, 'Output_Combined.xlsx')
            
            # Must be in the same directory as app.py
            template_path = os.path.join(os.getcwd(), 'Template.xlsx') 

            os.makedirs(pdf_dir, exist_ok=True)
            os.makedirs(json_dir, exist_ok=True)
            os.makedirs(img_dir, exist_ok=True)

            # Save uploaded PDFs to the temporary folder
            file_count = 0
            for file in uploaded_files:
                if file.filename.lower().endswith('.pdf'):
                    file_path = os.path.join(pdf_dir, file.filename)
                    file.save(file_path)
                    file_count += 1

            if file_count == 0:
                return "No valid PDF files uploaded", 400

            logger.info(f"📄 Processing {file_count} PDF files...")

            # Collect saved PDF paths
            pdf_paths = [
                os.path.join(pdf_dir, f)
                for f in os.listdir(pdf_dir)
                if f.lower().endswith('.pdf')
            ]

            try:
                # 1. Convert PDFs to JSON one-at-a-time to avoid OOM on large batches.
                #    Each subprocess exits fully before the next starts, freeing memory.
                logger.info("🔄 Step 1: Converting PDFs to JSON (one file at a time)...")
                failed_pdfs = []
                for i, pdf_path in enumerate(pdf_paths, 1):
                    logger.info(f"  📄 [{i}/{len(pdf_paths)}] {os.path.basename(pdf_path)}")
                    result = subprocess.run([
                        sys.executable, 'pdf_to_json.py',
                        '--input', pdf_path,
                        '--out', json_dir,
                        '--img', img_dir
                    ], check=False, timeout=120, stdin=subprocess.DEVNULL)
                    if result.returncode != 0:
                        logger.warning(f"  ⚠️ Failed to convert {os.path.basename(pdf_path)}, skipping.")
                        failed_pdfs.append(os.path.basename(pdf_path))
                    # Release memory between files
                    gc.collect()

                if failed_pdfs:
                    logger.warning(f"⚠️ {len(failed_pdfs)} PDF(s) skipped: {failed_pdfs}")

                json_count = len([f for f in os.listdir(json_dir) if f.endswith('.json')])
                if json_count == 0:
                    return "All PDFs failed to convert. Please check logs.", 500
                logger.info(f"✅ Step 1 complete: {json_count}/{len(pdf_paths)} JSONs created.")

                # 2. Convert all JSONs to a single combined Excel (one subprocess call)
                logger.info("🔄 Step 2: Generating Excel report...")
                result = subprocess.run([
                    sys.executable, 'json_to_excel.py', 
                    '--template', template_path, 
                    '--json-dir', json_dir, 
                    '--out', out_excel
                ], check=False, timeout=600, stdin=subprocess.DEVNULL)
                
                if result.returncode != 0:
                    logger.error(f"❌ JSON to Excel failed with return code {result.returncode}")
                    return "Excel generation failed. Please check Cloud Run logs for details.", 500

                logger.info("✅ Processing complete!")

                # Read output into memory before temp dir cleanup to avoid broken HTTP streaming.
                with open(out_excel, "rb") as f:
                    excel_bytes = f.read()

                return send_file(
                    io.BytesIO(excel_bytes),
                    as_attachment=True,
                    download_name='Compiled_MSS_Report.xlsx',
                    mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
                )

            except subprocess.TimeoutExpired as e:
                logger.error(f"❌ Processing timed out (>600 seconds): {str(e)}")
                return "Processing took too long. Please try with fewer files or contact support.", 504
            except subprocess.CalledProcessError as e:
                logger.error(f"❌ Subprocess error: {str(e)}")
                return f"Processing failed: {str(e)}", 500
            except Exception as e:
                logger.error(f"❌ Unexpected error in subprocess: {str(e)}\n{traceback.format_exc()}")
                return f"An unexpected error occurred: {str(e)}", 500
    
    except Exception as e:
        logger.error(f"❌ Critical error in process_files: {str(e)}\n{traceback.format_exc()}")
        return f"Critical error: {str(e)}", 500

if __name__ == '__main__':
    try:
        port = int(os.environ.get('PORT', 8080))
        logger.info(f"🚀 Starting server on port {port}")
        app.run(host='0.0.0.0', port=port, threaded=True)
    except Exception as e:
        logger.critical(f"❌ Failed to start server: {str(e)}\n{traceback.format_exc()}")
        sys.exit(1)