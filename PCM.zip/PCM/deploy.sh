#!/bin/bash

# Exit immediately if a command exits with a non-zero status
set -e

echo "🚀 Starting deployment to Google Cloud Run..."

# Set your variables
SERVICE_NAME="hr-bot"
REGION="asia-south1"
PROJECT_ID="mahindra-datalake"
VPC_CONNECTOR="projects/host-project-dev-env-mum/locations/asia-south1/connectors/serverless-vpc-connector"
AR_REPO="hr-bot-repo"
IMAGE_URI="$REGION-docker.pkg.dev/$PROJECT_ID/$AR_REPO/$SERVICE_NAME:$(date +%Y%m%d-%H%M%S)"

# Cloud Build with --tag expects a file named exactly 'Dockerfile'.
# Keep compatibility with existing lowercase 'dockerfile' in this repo.
if [ ! -f Dockerfile ] && [ -f dockerfile ]; then
  cp dockerfile Dockerfile
fi

# Ensure Artifact Registry repo exists in allowed region.
if ! gcloud artifacts repositories describe "$AR_REPO" --location "$REGION" --project "$PROJECT_ID" >/dev/null 2>&1; then
  gcloud artifacts repositories create "$AR_REPO" \
    --repository-format=docker \
    --location="$REGION" \
    --project="$PROJECT_ID"
fi

# Build and push image locally from Cloud Shell (avoids Cloud Build US bucket constraints)
echo "🐳 Building image locally: $IMAGE_URI"
gcloud auth configure-docker "$REGION-docker.pkg.dev" --quiet
docker build -t "$IMAGE_URI" .
docker push "$IMAGE_URI"

# Deploy built image to Cloud Run
gcloud run deploy $SERVICE_NAME \
  --image "$IMAGE_URI" \
  --project $PROJECT_ID \
  --region $REGION \
  --vpc-connector $VPC_CONNECTOR \
  --allow-unauthenticated \
  --concurrency 1 \
  --memory 16Gi \
  --cpu 8 \
  --max-instances 10 \
  --timeout 3600s

echo "✅ Deployment complete!"
echo "📦 Image deployed: $IMAGE_URI"
echo "⚠️  Note: Because ingress is set to 'internal', the Cloud Run URL will only be accessible to resources securely connected to the host-project-dev-env-mum VPC."