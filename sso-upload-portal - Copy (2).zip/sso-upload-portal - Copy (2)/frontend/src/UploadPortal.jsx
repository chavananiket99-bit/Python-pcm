import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import Header from "./Header";

const UPLOAD_CONFIG = {
  OPTION_1: {
    label: "3DS (Single Excel Upload)",
    allowMultiple: false,
    maxCount: 1,
    id: "opt_1",
    acceptType: ".xlsx, .xls",
    errorMessage:
      "The selected configuration (3DS) allows only a single Excel file upload.",
  },
  OPTION_2: {
    label: "PDF Converter (Multiple PDF Upload)",
    allowMultiple: true,
    maxCount: 5,
    id: "opt_2",
    acceptType: ".pdf",
    errorMessage:
      "The selected configuration (PDF Converter) allows only PDF file uploads.",
  },
};

function UploadPortal() {
  const [selectedOption, setSelectedOption] = useState("OPTION_1");
  const [files, setFiles] = useState([]);
  const [uploadStatus, setUploadStatus] = useState("");
  const [username, setUsername] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    const token = localStorage.getItem("sso_token");
    const loginTime = localStorage.getItem("login_time");
    const storedUsername = localStorage.getItem("sso_username");
    const TIMEOUT_DURATION = 15 * 60 * 1000;

    if (!token || !loginTime) {
      handleForceLogout();
      return;
    }

    if (Date.now() - parseInt(loginTime, 10) > TIMEOUT_DURATION) {
      alert("Session expired. Please log in again.");
      handleForceLogout();
      return;
    }

    setUsername(storedUsername || "Active User");

    const sessionCheckInterval = setInterval(() => {
      if (Date.now() - parseInt(loginTime, 10) > TIMEOUT_DURATION) {
        clearInterval(sessionCheckInterval);
        alert("Session expired. Please log in again.");
        handleForceLogout();
      }
    }, 10000);

    return () => clearInterval(sessionCheckInterval);
  }, [navigate]);

  const handleForceLogout = () => {
    localStorage.clear();
    navigate("/");
  };

  const handleDropdownChange = (e) => {
    setSelectedOption(e.target.value);
    setFiles([]);
    setUploadStatus("");
  };

  const currentSettings = UPLOAD_CONFIG[selectedOption];

  const handleFileChange = (e) => {
    const selectedFiles = Array.from(e.target.files);

    if (!currentSettings.allowMultiple && selectedFiles.length > 1) {
      setUploadStatus(
        `The selected configuration (${currentSettings.label}) allows only a single file.`,
      );
      e.target.value = null;
      setFiles([]);
      return;
    }

    if (selectedFiles.length > currentSettings.maxCount) {
      setUploadStatus(
        `You can upload a maximum of ${currentSettings.maxCount} files for the selected configuration (${currentSettings.label}).`,
      );
      e.target.value = null;
      setFiles([]);
      return;
    }

    const validExtensions = currentSettings.acceptType
      .split(",")
      .map((ext) => ext.trim().toLowerCase());

    const inputClearance = selectedFiles.every((file) => {
      const fileNameLower = file.name.toLowerCase();
      return validExtensions.some((ext) => fileNameLower.endsWith(ext));
    });

    if (!inputClearance) {
      setUploadStatus(
        `Invalid file type detected. Please upload files with the following extensions: ${currentSettings.errorMessage}`,
      );
      e.target.value = null;
      setFiles([]);
      return;
    }

    setFiles(selectedFiles);
    setUploadStatus("");
  };

  const handleUploadSubmit = async (e) => {
    e.preventDefault();
    if (files.length === 0)
      return setUploadStatus("⚠️ Please select at least one file.");

    const formData = new FormData();
    files.forEach((file) => formData.append("files", file));
    formData.append("selectedOptionFlag", currentSettings.id);

    try {
      setUploadStatus("Uploading...");
      const token = localStorage.getItem("sso_token");

      const response = await axios.post(
        "http://localhost:5000/api/upload",
        formData,
        {
          headers: {
            "Content-Type": "multipart/form-data",
            Authorization: `Bearer ${token}`,
          },
        },
      );
      setUploadStatus(`${response.data.message}`);
    } catch (error) {
      setUploadStatus(
        `Error: ${error.response?.data?.error || "Upload failed."}`,
      );
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 flex flex-col items-center">
      <Header username={username} onLogout={handleForceLogout} />
      <main className="flex-1 flex flex-col items-center justify-center p-6 w-full">
        <div className="w-[400px] bg-white rounded-2xl shadow-xl p-8 border border-slate-100 relative">
          <div className="text-center mb-6">
            <h1 className="text-xl font-bold text-slate-900">
              Secure Document Portal
            </h1>
            <p className="text-xs text-slate-500 mt-1">
              SSO Session Authenticated
            </p>
          </div>
          <div className="mb-6 space-y-2">
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-500">
              Processing Configuration
            </label>
            <select
              value={selectedOption}
              onChange={handleDropdownChange}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 text-sm font-medium text-slate-700 shadow-sm focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-red-500 transition cursor-pointer"
            >
              <option value="OPTION_1">3DS Mode (Excel only)</option>
              <option value="OPTION_2">PDF Converter Mode (PDF only)</option>
            </select>
          </div>

          <form onSubmit={handleUploadSubmit} className="space-y-4">
            <label className="block text-sm font-medium text-slate-700">
              Attch Documents
            </label>
            <div className="border-2 border-dashed border-slate-200 rounded-xl p-6 text-center hover:border-slate-300 transition-colors bg-slate-50/50">
              <input
                type="file"
                key={selectedOption}
                onChange={handleFileChange}
                accept={currentSettings.acceptType}
                multiple={currentSettings.allowMultiple}
                className="block w-full text-sm text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-semibold file:bg-slate-900 file:text-white hover:file:bg-slate-800 cursor-pointer"
              />
              <p className="text-[11px] text-slate-400 mt-3">
                Expected Format:
                <span className="font-bold text-slate-600 uppercase">
                  {currentSettings.acceptType}
                </span>
              </p>
            </div>

            {files.length > 0 && (
              <div className="bg-slate-50 p-3 rounded-lg border border-slate-100 space-y-1">
                {files.map((file, idx) => (
                  <div key={idx} className="text-xs text-slate-600 truncate">
                    {file.name}
                  </div>
                ))}
              </div>
            )}

            <button
              type="submit"
              className="w-full bg-red-600 hover:bg-red-500 text-white font-medium py-2.5 px-4 rounded-xl shadow-md transition-all text-sm cursor-pointer"
            >
              Upload Files
            </button>
          </form>
          {uploadStatus && (
            <div className="mt-4 text-center p-3 rounded-lg text-sm bg-slate-50 border border-slate-100 font-medium">
              {uploadStatus}
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
export default UploadPortal;
