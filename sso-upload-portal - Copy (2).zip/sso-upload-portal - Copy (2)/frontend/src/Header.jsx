import react from "react";
import logoImageInner from "./assets/rise-red.png";

function Header({ username, onLogout }) {
  return (
    <header className="w-full h-16 bg-white border-b border-slate-200 px-6 flex items-center justify-between shadow-sm sticky top-0 z-50">
      <div className="flex items-center">
        <img src={logoImageInner} alt="Logo" className="h-8 w-auto" />
      </div>
      <div className="hidden md:block">
        <h1 className="text-sm font-bold tracking-wide uppercase text-slate-700">
          PCM Engineering Portal
        </h1>
      </div>
      <div className="flex items-center gap-4">
        {username && (
          <div className="text-right hidden sm:block border-r border-slate-200 pr-4">
            <p className="text-xs font-semibold text-slate-800">{username}</p>
            <p className="text-[10px] text-emerald-600 font-medium">
              SSO Authenticated
            </p>
          </div>
        )}
        <button
          onClick={onLogout}
          className="bg-[#e8354f] hover:bg-red-500 text-white font-medium py-2 px-4 rounded-xl shadow-lg shadow-red-600/20 transition-all text-sm cursor-pointer"
        >
          Logout
        </button>
      </div>
    </header>
  );
}

export default Header;
