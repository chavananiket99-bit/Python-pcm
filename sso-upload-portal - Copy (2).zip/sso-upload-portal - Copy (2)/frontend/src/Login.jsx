import React from "react";
import { useNavigate } from "react-router-dom";
import backgroundImage from "./assets/bg.png";
import logoImage from "./assets/rise_white.png";

function Login() {
  const navigate = useNavigate();

  const handleSSOLogin = () => {
    const mockToken = "mock_sso_token_for_user";
    const loginTime = Date.now();

    localStorage.setItem("sso_token", mockToken);
    localStorage.setItem("login_time", loginTime.toString());
    localStorage.setItem("sso_username", "Aniket Chavan");

    navigate("/upload");
  };

  return (
    <div
      className="min-h-screen w-full bg-cover bg-center bg-no-repeat flex flex-col items-center justify-center p-6 relative"
      style={{ backgroundImage: `url(${backgroundImage})` }}
    >
      <div className="absolute inset-0 bg-slate-950/70 z-0"></div>
      <div className="absolute top-6 left-6 z-20 flex items-center ">
        <img src={logoImage} alt="Logo" className="h-8 w-auto" />
      </div>
      <div className="w-full max-w-md bg-slate-800/70 rounded-2xl shadow-2xl p-8 border border-slate-700 text-center z-2">
        <div className="mb-8">
          <div className="h-12 w-12 bg-[#e8354f] rounded-xl mx-auto flex items-center justify-center text-xl font-bold shadow-lg shadow-red-500/50">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="16"
              height="16"
              fill="currentColor"
              className="bi bi-shield-lock"
              viewBox="0 0 16 16"
            >
              <path d="M5.338 1.59a61 61 0 0 0-2.837.856.48.48 0 0 0-.328.39c-.554 4.157.726 7.19 2.253 9.188a10.7 10.7 0 0 0 2.287 2.233c.346.244.652.42.893.533q.18.085.293.118a1 1 0 0 0 .101.025 1 1 0 0 0 .1-.025q.114-.034.294-.118c.24-.113.547-.29.893-.533a10.7 10.7 0 0 0 2.287-2.233c1.527-1.997 2.807-5.031 2.253-9.188a.48.48 0 0 0-.328-.39c-.651-.213-1.75-.56-2.837-.855C9.552 1.29 8.531 1.067 8 1.067c-.53 0-1.552.223-2.662.524zM5.072.56C6.157.265 7.31 0 8 0s1.843.265 2.928.56c1.11.3 2.229.655 2.887.87a1.54 1.54 0 0 1 1.044 1.262c.596 4.477-.787 7.795-2.465 9.99a11.8 11.8 0 0 1-2.517 2.453 7 7 0 0 1-1.048.625c-.28.132-.581.24-.829.24s-.548-.108-.829-.24a7 7 0 0 1-1.048-.625 11.8 11.8 0 0 1-2.517-2.453C1.928 10.487.545 7.169 1.141 2.692A1.54 1.54 0 0 1 2.185 1.43 63 63 0 0 1 5.072.56" />
              <path d="M9.5 6.5a1.5 1.5 0 0 1-1 1.415l.385 1.99a.5.5 0 0 1-.491.595h-.788a.5.5 0 0 1-.49-.595l.384-1.99a1.5 1.5 0 1 1 2-1.415" />
            </svg>
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-white mt-4">
            Welcome to the PCM Engineering Portal
          </h1>
          <p className="text-sm text-slate-400 mt-1">
            Please click below to simulate SSO login.
          </p>
        </div>
        <button
          onClick={handleSSOLogin}
          className="w-full bg-[#e8354f] hover:bg-red-500 text-white font-medium py-3 px-4 rounded-xl shadow-lg shadow-red-600/20 transition-all text-sm flex items-center justify-center gap-2 cursor-pointer"
        >
          Authenticate with SSO
        </button>
        <div className="mt-6 p-3 bg-slate-800/50 border border-slate-700/80 rounded-lg text-left">
          <p className="text-[13px] text-slate-500 leading-relaxed text-center">
            <strong>Note:</strong> Access given to authorized personnel.
          </p>
        </div>
      </div>
    </div>
  );
}

export default Login;
