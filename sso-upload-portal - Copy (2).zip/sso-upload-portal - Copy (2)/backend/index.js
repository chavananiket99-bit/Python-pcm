const express = require("express");
const cors = require("cors");
const multer = require("multer");
const jwt = require("jsonwebtoken");
require("dotenv").config();

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

const upload = multer({
  dest: "uploads/",
  limits: { fileSize: 5 * 1024 * 1024 },
}).array("files", 10);

const verifySSOToken = (req, res, next) => {
  const token = req.headers["authorization"]?.split(" ")[1];
  if (!token) return res.status(401).json({ error: "No token provided" });
  next();
};

app.post("/api/upload", verifySSOToken, (req, res) => {
  upload(req, res, function (err) {
    if (err instanceof multer.MulterError) {
      return res
        .status(400)
        .json({ error: `File framework error: ${err.message}` });
    } else if (err) {
      return res
        .status(500)
        .json({ error: `Server upload failure: ${err.message}` });
    }

    const selectedOptionFlag = req.body.selectedOptionFlag;
    const fileCount = req.files ? req.files.length : 0;

    if (fileCount === 0) {
      return res.status(400).json({ error: "No files uploaded" });
    }

    for (let i = 0; i < fileCount; i++) {
      const file = req.files[i];
      const extension = file.originalname.split(".").pop().toLowerCase();

      if (selectedOptionFlag === "opt_1") {
        const allowedExcelMimeTypes = [
          "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
          "application/vnd.ms-excel",
        ];
        if (
          !allowedExcelMimeTypes.includes(file.mimetype) &&
          !["xls", "xlsx"].includes(extension)
        ) {
          return res.status(422).json({
            error:
              "Security Failure: 3DS Mode only accepts Excel files (.xls, .xlsx).",
          });
        }
      }

      if (selectedOptionFlag === "opt_2") {
        if (file.mimetype !== "application/pdf" && extension !== "pdf") {
          return res.status(422).json({
            error:
              "Security Failure: PDF Converter Mode only accepts PDF files (.pdf).",
          });
        }
      }
    }

    if (selectedOptionFlag === "opt_1" && fileCount > 1) {
      return res.status(403).json({
        error: "Security Failure: 3DS Mode allows only a single file upload.",
      });
    }

    if (selectedOptionFlag === "opt_2" && fileCount > 5) {
      return res.status(403).json({
        error:
          "Security Failure: PDF Converter Mode allows a maximum of 5 files per upload.",
      });
    }

    res.status(200).json({
      message: `Successfully uploaded ${fileCount} file(s) under configuration (${selectedOptionFlag}).`,
    });
  });
});

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
